from src.common import xml_to_dict


def test():
    xml_to_dict("")
    print("Test")
